import History from "../Components/History";

function Team(){
    return(
    <section id="team">
        <h2 className="main_title">TEAM SSG LANDERS</h2>
        <History />
    </section>
    )
}
export default Team;